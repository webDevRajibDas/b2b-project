$(document).ready(function() {
    $('#target_customer').select2();
});